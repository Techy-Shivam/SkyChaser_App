package com.example.skychaser

data class Coord(
    val lat: Double,
    val lon: Double
)