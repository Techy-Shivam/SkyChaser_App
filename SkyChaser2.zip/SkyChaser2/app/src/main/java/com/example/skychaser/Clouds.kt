package com.example.skychaser

data class Clouds(
    val all: Int
)