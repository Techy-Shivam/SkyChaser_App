package com.example.skychaser

data class Wind(
    val deg: Int,
    val speed: Double
)